
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.XmlList;
import com.sun.codemodel.JAnnotationWriter;

public interface XmlListWriter
    extends JAnnotationWriter<XmlList>
{


}
