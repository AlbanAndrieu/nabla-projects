package com.sun.xml.bind.v2.model.runtime;

import java.lang.reflect.Type;

import com.sun.xml.bind.v2.model.core.Element;

/**
 * @author Kohsuke Kawaguchi
 */
public interface RuntimeElement extends Element<Type,Class>, RuntimeTypeInfo {
}
