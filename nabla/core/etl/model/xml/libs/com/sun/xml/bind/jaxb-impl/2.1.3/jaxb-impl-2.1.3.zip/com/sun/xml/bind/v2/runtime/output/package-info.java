/**
 * Code that writes well-formed XML ({@link XmlOutput} and its implementations}.
 */
package com.sun.xml.bind.v2.runtime.output;