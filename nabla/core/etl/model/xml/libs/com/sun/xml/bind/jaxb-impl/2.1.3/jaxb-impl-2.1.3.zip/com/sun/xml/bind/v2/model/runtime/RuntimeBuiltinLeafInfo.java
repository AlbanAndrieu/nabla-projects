package com.sun.xml.bind.v2.model.runtime;

import java.lang.reflect.Type;

import com.sun.xml.bind.v2.model.core.BuiltinLeafInfo;

/**
 * @author Kohsuke Kawaguchi
 */
public interface RuntimeBuiltinLeafInfo extends BuiltinLeafInfo<Type,Class>, RuntimeLeafInfo {
}
